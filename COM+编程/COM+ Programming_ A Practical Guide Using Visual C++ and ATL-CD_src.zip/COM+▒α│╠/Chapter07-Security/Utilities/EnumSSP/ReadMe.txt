Utility to enumerate installed SSPs on the local machine.
