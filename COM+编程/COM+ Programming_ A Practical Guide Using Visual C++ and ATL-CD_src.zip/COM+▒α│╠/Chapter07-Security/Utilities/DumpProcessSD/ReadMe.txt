Utility to dump process' security descriptor.
