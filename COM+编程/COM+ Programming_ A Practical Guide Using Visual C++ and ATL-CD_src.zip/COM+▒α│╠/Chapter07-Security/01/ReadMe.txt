Demonstration of programmatic role based security
for a COM+ configured application.

