Demonstrates the effect of various impersonation levels.
