Moving memory management responsibility to VCR.

