Monolithic app broken into TV and VCR components.
Linked statically.

