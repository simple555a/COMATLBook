Taking AddReference public

