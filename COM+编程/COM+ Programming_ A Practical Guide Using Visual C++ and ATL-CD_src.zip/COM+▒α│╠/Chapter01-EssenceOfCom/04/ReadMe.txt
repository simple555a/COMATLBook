Gaining compiler independence by defining an abstract
class as our interface. Also using _stdcall calling convention.


