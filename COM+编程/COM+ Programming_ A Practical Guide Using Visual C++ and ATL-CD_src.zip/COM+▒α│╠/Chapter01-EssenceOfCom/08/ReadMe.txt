Adding reference-counting mechanism

