// File vcr.h

class CVcr
{
public:
	CVcr(void);

	long GetSignalValue();

private:
	long m_lCurValue;
};

