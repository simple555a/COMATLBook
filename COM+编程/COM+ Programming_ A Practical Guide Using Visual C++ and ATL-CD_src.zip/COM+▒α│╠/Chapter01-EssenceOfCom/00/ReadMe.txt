Monolithic application - TV-VCR together.

