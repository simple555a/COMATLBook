Optimization of obtaining first interface

