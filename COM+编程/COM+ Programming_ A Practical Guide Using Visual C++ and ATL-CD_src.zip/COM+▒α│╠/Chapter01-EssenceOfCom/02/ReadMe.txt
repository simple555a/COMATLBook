Just the VCR component built with a fix.
Use it with old TV. Showing field-replacement.

