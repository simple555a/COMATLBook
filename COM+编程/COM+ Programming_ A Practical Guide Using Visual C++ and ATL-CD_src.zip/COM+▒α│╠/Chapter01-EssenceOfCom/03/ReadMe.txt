Separating implementation and interface.
Still linked statically.


