Adding error status mechanism.

