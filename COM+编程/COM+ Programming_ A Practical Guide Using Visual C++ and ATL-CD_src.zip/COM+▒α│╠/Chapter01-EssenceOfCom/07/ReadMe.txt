Multiple interfaces.
Creating a base interface class - IGeneral

