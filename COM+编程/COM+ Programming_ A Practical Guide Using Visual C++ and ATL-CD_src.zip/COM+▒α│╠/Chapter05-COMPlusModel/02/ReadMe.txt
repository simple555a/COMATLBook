Demonstrates local as well as remote activation.
Need to install the dll on both the machines.
