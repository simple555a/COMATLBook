Demonstrates the use of IObjectConstruct
