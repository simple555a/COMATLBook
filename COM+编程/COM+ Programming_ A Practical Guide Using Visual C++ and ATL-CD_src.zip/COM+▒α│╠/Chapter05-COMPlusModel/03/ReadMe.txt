Demonstrates FTM
