// MyTestD.cpp : Implementation of CMyTestD
#include "stdafx.h"
#include "TestD.h"
#include "MyTestD.h"

/////////////////////////////////////////////////////////////////////////////
// CMyTestD


STDMETHODIMP CMyTestD::DoIt()
{
	// TODO: Add your implementation code here

	return S_OK;
}
