// File Resource.h

#define IDR_VCR  100
