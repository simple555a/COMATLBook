Converted non-ATL in-proc server code to ATL based.

