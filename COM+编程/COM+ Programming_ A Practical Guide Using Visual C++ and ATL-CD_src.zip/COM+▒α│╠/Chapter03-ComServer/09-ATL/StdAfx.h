// File StdAfx.h

#pragma once

#define WIN32_LEAN_AND_MEAN
#define _ATL_MIN_CRT
#define _USRDLL

#include <atlbase.h>
extern CComModule _Module;
#include <atlcom.h>

