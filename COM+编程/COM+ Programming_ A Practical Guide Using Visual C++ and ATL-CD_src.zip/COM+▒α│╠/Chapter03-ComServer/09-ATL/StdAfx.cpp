// File StdAfx.cpp : source file that includes just the standard includes

#include "StdAfx.h"

#include <atlimpl.cpp>
