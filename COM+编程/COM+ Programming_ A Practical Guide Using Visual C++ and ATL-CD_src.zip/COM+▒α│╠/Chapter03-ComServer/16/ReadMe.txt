Using native C++ support for error display as well as CCI.


