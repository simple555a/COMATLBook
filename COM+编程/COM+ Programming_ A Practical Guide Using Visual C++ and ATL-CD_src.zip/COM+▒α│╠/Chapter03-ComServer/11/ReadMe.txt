Creating a new COM server to support Component Video.
Demonstrating containment.

Build projects in the following order:
 - ComponentVCR
 - MyVCR
 - TV



