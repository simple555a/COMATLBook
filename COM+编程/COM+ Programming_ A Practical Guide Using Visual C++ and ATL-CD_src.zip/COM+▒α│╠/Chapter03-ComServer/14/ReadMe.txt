Fixing resource leaks in the client code.


