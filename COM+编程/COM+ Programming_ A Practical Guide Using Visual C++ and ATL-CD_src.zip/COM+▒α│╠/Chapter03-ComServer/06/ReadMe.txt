Adding class object deletion code in DllMain.

