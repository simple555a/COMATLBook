Moving global variables to a struct in MyModule.h.
Adding StdAfx.h.

