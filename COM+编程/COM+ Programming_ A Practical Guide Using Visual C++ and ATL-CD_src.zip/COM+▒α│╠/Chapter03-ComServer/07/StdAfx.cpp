// File "StdAfx.cpp"

#include "StdAfx.h"


MYMODULEINFO g_MyModule;

