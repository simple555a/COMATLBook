Demonstrating aggregation.

Build projects in the following order:
 - ComponentVCR
 - MyVCR
 - TV


