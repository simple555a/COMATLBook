Code Base is from Directory 09.

Using custom HRESULTs.
Writing client program, classic style.


