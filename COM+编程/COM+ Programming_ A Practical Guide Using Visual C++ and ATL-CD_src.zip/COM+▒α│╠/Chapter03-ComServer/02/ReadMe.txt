Using static variable for class object.
Also, TV using two sources.


