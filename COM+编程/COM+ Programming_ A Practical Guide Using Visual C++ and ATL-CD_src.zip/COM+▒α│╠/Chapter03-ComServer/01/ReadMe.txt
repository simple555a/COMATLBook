From C++ to COM - A quick conversion
