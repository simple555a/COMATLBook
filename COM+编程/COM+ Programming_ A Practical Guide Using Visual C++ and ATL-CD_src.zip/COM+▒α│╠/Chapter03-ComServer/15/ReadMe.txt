Supporting extended error information - IErrorInfo



