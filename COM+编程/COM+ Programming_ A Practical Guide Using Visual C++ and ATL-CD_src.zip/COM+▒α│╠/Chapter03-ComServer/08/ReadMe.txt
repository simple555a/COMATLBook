Adding global counter to keep track of number of objects.
Adding LockServer code.

