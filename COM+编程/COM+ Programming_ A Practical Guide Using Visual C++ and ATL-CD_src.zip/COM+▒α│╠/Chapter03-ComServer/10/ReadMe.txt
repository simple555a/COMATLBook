Converting DLL based code to EXE based.

