Demonstrating aggregation using ATL.


