From C++ to COM - A quick conversion.
Similar to sample "01" but using __uuidof
keyword.

