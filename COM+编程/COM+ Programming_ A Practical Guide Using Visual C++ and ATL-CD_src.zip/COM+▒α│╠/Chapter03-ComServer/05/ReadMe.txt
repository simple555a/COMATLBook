Adding registration logic.

