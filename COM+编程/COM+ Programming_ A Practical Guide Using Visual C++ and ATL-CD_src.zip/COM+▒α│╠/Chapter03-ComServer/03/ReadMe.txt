Separating class object from com object.



