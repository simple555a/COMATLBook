// File "StdAfx.cpp"

#include "StdAfx.h"


CMyModule g_MyModule;

