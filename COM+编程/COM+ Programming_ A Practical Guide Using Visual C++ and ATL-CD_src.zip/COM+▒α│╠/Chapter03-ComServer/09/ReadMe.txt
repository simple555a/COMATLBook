Rearranging the code to make it more manageable:

1. Converting MYMODULEINFO struct to CMyModule class.
2. Adding GetUnknown method.


