Demonstrating COM Singletons

