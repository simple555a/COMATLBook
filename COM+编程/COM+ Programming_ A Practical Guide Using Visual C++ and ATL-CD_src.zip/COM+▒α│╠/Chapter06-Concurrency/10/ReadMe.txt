Using Shared property manager
