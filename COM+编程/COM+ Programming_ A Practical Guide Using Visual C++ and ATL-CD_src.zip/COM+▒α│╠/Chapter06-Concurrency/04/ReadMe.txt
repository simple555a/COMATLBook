Experiment to see which thread is used
when traveling from STA->TNA->MTA or MTA->TNA->MTA.
