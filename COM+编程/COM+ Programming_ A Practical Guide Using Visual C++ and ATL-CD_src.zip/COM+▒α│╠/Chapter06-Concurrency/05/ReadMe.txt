
Client using various marshaling mechanisms.
Check "Client\ReadMe.txt" for more information.

