Demonstrating "Events" synchronization primitive.
