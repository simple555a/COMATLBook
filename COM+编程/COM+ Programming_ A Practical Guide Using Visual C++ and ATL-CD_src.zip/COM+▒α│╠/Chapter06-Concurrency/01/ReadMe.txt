Shows using a thread using Win32 APIs.
