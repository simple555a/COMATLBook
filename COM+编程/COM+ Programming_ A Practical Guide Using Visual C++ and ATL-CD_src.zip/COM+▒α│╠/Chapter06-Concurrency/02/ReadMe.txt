
Demonstrating CCPLWinThread usage.
