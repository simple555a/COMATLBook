Effect of SetDeactivateOnReturn on the output

Build instructions:

1. Load TradeMgmt
2. Build AccountMgmt, StockExchnage, TradeMgmt in order
