No transaction support.

Build Instructions

1. Load TradeMgmt Workspace
2. Build AccountMgmt, StockExchange, TradeMgmt in order
