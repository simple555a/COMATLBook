A program to decode HRESULTs.
