A program to generate GUIDs.
