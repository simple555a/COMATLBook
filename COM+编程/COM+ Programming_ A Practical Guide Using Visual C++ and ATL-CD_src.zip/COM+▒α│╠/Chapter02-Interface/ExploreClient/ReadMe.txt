Client program to explore various possibilities
of IDL.

Function TestMethods contains calls to various
other function, each of which explores one aspect
of IDL. Uncomment one function at a time and
explore the IDL feature.

NOTE: Need to build ExplorIDL project first.