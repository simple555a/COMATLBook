#if !defined(DUMPERROR_INCLUDED)
#define DUMPERROR_INCLUDED

void DumpError(HRESULT hr);

#endif // DUMPERROR_INCLUDED

