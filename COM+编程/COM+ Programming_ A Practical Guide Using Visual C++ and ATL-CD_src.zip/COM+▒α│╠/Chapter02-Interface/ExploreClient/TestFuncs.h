void RandomValue(IMyExplore* pMyExplore);
void DirectionDemo(IMyExplore* pMyExplore);
void StringDemo(IMyExplore* pMyExplore);
void BstrStringDemo(IMyExplore* pMyExplore);
void GetStringDemo(IMyExplore* pMyExplore);
void GetEnumDemo(IMyExplore* pMyExplore);
void TestAliasDemo(IMyExplore* pMyExplore);
void TestCircularBuf(IMyExplore* pMyExplore);
void TestEmbeddedDemo(IMyExplore* pMyExplore);
void TestArrayDemo(IMyExplore* pMyExplore);
void TestSimpleStruct(IMyExplore* pMyExplore);
void TestSimpleArrayDemoIn(IMyExplore* pMyExplore);
void TestSimpleArrayDemoOut(IMyExplore* pMyExplore);
void TestSimpleUnionIn(IMyExplore* pMyExplore);
void TestEUnionIn(IMyExplore* pMyExplore);
void TestConformantIn(IMyExplore* pMyExplore);
void TestConformantOut(IMyExplore* pMyExplore);
void TestConformantIn2(IMyExplore* pMyExplore);

void GetGrades1(IMyExplore* pMyExplore);
void GetGrades2(IMyExplore* pMyExplore);
void GetGrades3(IMyExplore* pMyExplore);
void GetGrades4(IMyExplore* pMyExplore);
void GetGrades5(IMyExplore* pMyExplore);
void GetGrades6(IMyExplore* pMyExplore);

void LinkListDemo(IMyExplore* pMyExplore);
void CircularListDemo(IMyExplore* pMyExplore);
void MemoryMgmtDemo(IMyExplore* pMyExplore);


