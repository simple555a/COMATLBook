Interfaces from Chapter 1 defined as IDL interfaces.
