COM server that demonstrates various features of IDL.

Build ExploreIDL project followed by ExploreIDLProxyStub project.
