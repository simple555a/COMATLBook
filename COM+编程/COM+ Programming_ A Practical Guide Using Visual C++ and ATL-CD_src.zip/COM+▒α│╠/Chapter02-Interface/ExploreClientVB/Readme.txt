A Visual basic project to explore IDL features.

NOTE: Build ExploreIDL first.
