A VB script to demonstrate collection objects.
This program reads filenames from c:\winnt directory.
