This program generates a makefile and a .def file to
for creating a proxy-stub dll.

Usage: CreatePS basefilename [-r]
       Options:
	      -r -- Adds logic into the makefile
		        to register the dll after creation
